@Repository
public interface ProductRepository extends JpaRepository<Product, Long> {
    // Task 3.2: Custom finder method[cite: 10]
    List<Product> findByCategory(String category);

    // Custom JPQL Query para sa price range[cite: 10]
    @Query("SELECT p FROM Product p WHERE p.price BETWEEN :min AND :max")
    List<Product> findByPriceRange(@Param("min") double min, @Param("max") double max);
}